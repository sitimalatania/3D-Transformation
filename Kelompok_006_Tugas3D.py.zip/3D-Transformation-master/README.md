# Transformasi 3D

Tugas Kelompok Teknik Visualisasi Grafis
Kelompok 6 :
1. Annisa Raihana Cahya Putri   (20/460540/TK/51129)
2. Auletta Khansa Pradiviasari  (20/456359/TK/50489)
3. Hervi Nur Rahmandien         (20/463601/TK/51593)
4. Rahmiyatul Hasanah YE        (20/460561/TK/51150)
5. Siti Malatania               (20/456380/TK/50510)

Program transformasi 3D pada bangun balok menggunakan python

